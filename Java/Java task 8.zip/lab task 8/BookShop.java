import java.lang.*;
class BookShop implements BookShopOperations
{
private String name;
private Book listOfBooks[];

public BookShop()
{
	this.listOfBooks=new Book[100];
}
public BookShop(String name)
{
this.listOfBooks=new Book[100];
}
public void setName(String name)
{
	this.name=name;
}
public String getName()
{
	return this.name;
}
public boolean insertBook(Book b)
{
  for(int i=0;i<this.listOfBooks.length;i++)
{
     if(this.listOfBooks[i]==null)
{
      this.listOfBooks[i]=b;
         return true;
}
}
return false;
}
public boolean removeBook(Book b)
{
      for(int i=0;i<this.listOfBooks.length;i++)
{
        if(this.listOfBooks[i].getIsbn().equalsIgnoreCase(b.getIsbn()))
{
          for(int j=i;j<this.listOfBooks.length;j++)
{
            if(j!=this.listOfBooks.length-1)
{
              this.listOfBooks[j]=this.listOfBooks[j+1];
}
else
{
	this.listOfBooks[j]=null;
}
}
    return true;}
}
      return false;
}
public void showAllBooks()
 {
	
       for(int i=0;i<this.listOfBooks.length;i++)
{
           if(this.listOfBooks[i]!=null)
{
              this.listOfBooks[i].showDetails();
}
}    
}
public Book searchBook(String isbn)
{
     for(int i=0;i<this.listOfBooks.length;i++)
{
         if(this.listOfBooks[i]!=null)
{
            if(this.listOfBooks[i].getIsbn().equalsIgnoreCase(isbn))
{
                return this.listOfBooks[i];}}
} 
return null;
}
}