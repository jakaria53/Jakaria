
import java.lang.*;
interface BookOperations
{
   public void addQuantity(int amount);
      public void sellQuantity(int amount);
}