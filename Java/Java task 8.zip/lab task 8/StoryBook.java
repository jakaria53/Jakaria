
import java.lang.*;
class StoryBook extends Book
{
private String category;
public StoryBook(){}
public StoryBook(String isbn,String bookTitle,String authorName,double price,int availableQuantity,String category)
{
super(isbn,bookTitle,authorName,price,availableQuantity);
setCategory(category);
}

public void setCategory(String category)
{
	this.category=category;
}
public String getCategory()
{
	return this.category;
}
public void showDetails()
{
System.out.println("\nIsbn: "+this.getIsbn());
System.out.println("Book Title: "+this.getBookTitle());
System.out.println("Author Name: "+this.getAuthorName());
System.out.println("Price: "+this.getPrice());
System.out.println("Available Quantity: "+this.getAvailableQuantity());
System.out.println("Category: "+this.getCategory());
}
public void addQuantity(int amount)
{
this.setAvailableQuantity(this.getAvailableQuantity()+amount);
}
public void sellQuantity(int amount)
{
if(this.getAvailableQuantity()-amount>=0)
{
this.setAvailableQuantity(this.getAvailableQuantity()-amount);
}
System.out.println("Invalid input.");
}
}