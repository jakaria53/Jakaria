
import java.lang.*;
public class Start
{
public static void main(String[] args)
{

Book obj1=new StoryBook("121","Cat in the Hat","Dr. Seuss",9.27,5,"Classic");
Book obj2=new StoryBook("212","Charlotte's Web","E.B. White",6,5,"Classic");
Book obj3=new StoryBook("343","Little Women","Louis May Alcott",12,5,"Classic");
StoryBook obj4=new StoryBook("434","Philosopher's Stone","J.K. Rowling",7.50,5,"Fantasy");
StoryBook obj5=new StoryBook("565","Chronicles of Narnia","C.S. Lewis",9,5,"Fantasy");

Book obj6=new TextBook("656","Science of Life","Alex Brent",10,5,6);
Book obj7=new TextBook("787","Design Programs","Linda H.",9.5,5,7);
TextBook obj8=new TextBook("898","DSA","C.V Lax",8,5,8);
TextBook obj9=new TextBook("989","Civics","Jen Wilson",12,5,8);
TextBook obj10=new TextBook("1000","Calculus","Ronald K.",7,5,9);

BookShop shop=new BookShop();
shop.setName("Modern Plaza");
shop.insertBook(obj1);
shop.insertBook(obj2);
shop.insertBook(obj3);
shop.insertBook(obj4);
shop.insertBook(obj5);
shop.insertBook(obj6);
shop.insertBook(obj7);
shop.insertBook(obj8);
shop.insertBook(obj9);
shop.insertBook(obj10);

shop.removeBook(obj4);
shop.removeBook(obj8);
shop.showAllBooks();

Book obj=shop.searchBook("111");
if(obj!=null){obj.showDetails();
}
else{
	System.out.println("\nBook not available.");
    }
}
}