import java.lang.*;
abstract class Book implements BookOperations
{
private String isbn,bookTitle,authorName;
private double price;
private int availableQuantity;

public Book()
{
	
}
public Book(String isbn,String bookTitle,String authorName,double price,int availableQuantity)
{
setIsbn(isbn);
setBookTitle(bookTitle);
setAuthorName(authorName);
setPrice(price);
setAvailableQuantity(availableQuantity);
}

public void setIsbn(String isbn)
{
	this.isbn=isbn;
}
public void setBookTitle(String bookTitle)
{
	this.bookTitle=bookTitle;
}
public void setAuthorName(String authorName)
{
	this.authorName=authorName;
}
public void setPrice(double price)
{
	this.price=price;
}
public void setAvailableQuantity(int availableQuantity)
{
	this.availableQuantity=availableQuantity;
}
public String getIsbn()
{
	return this.isbn;
}
public String getBookTitle()
{
	return this.bookTitle;
}
public String getAuthorName()
{
	return this.authorName;
}
public double getPrice()
{
	return this.price;
}
public int getAvailableQuantity()
{
	return this.availableQuantity;
}
public abstract void showDetails();
}