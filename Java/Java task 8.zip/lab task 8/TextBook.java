
import java.lang.*;
class TextBook extends Book
{
private int standard;
public TextBook(){}
public TextBook(String isbn,String bookTitle,String authorName,double price,int availableQuantity,int standard)
{
super(isbn,bookTitle,authorName,price,availableQuantity);
setStandard(standard);
}

public void setStandard(int standard)
{
	this.standard=standard;
}
public int getStandard()
{
	return this.standard;
}
public void showDetails()
{
System.out.println("\nIsbn: "+this.getIsbn());
System.out.println("Book Title: "+this.getBookTitle());
System.out.println("Author Name: "+this.getAuthorName());
System.out.println("Price: "+this.getPrice());
System.out.println("Available Quantity: "+this.getAvailableQuantity());
System.out.println("Standard: "+this.getStandard());
}
public void addQuantity(int amount)
{
this.setAvailableQuantity(this.getAvailableQuantity()+amount);
}
public void sellQuantity(int amount)
{
if(this.getAvailableQuantity()-amount>=0)
{
this.setAvailableQuantity(this.getAvailableQuantity()-amount);
}
System.out.println("Invalid input.");
}
}