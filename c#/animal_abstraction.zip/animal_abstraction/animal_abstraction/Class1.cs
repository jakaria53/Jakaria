﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace animal_abstraction
{
    abstract class animal
    {
        public abstract void animalsound();
        public void sound()
        {
            Console.WriteLine("The animal makes a sound");
            Console.WriteLine("");
        }
    }
}
