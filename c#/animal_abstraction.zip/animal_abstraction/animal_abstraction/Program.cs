﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace animal_abstraction
{
    internal class program
    {
        static void Main(string[] args)
        {
            Cow mycow = new Cow(); // Create a cow object
            mycow.animalsound();  // Call the abstract method
            mycow.sound();

            Dog d = new Dog();
            d.animalsound();
            d.sound();

            Cat c = new Cat();
            c.animalsound();
            c.sound();
        }
    }
}
