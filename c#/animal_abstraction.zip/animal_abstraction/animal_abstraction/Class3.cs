﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace animal_abstraction
{
   
        class Dog : animal
        {
            public override void animalsound()
            {
                Console.WriteLine("Dog says: Woof");
            }
        }
    }

