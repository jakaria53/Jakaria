﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace animal_abstraction
{
    internal class Cat:animal
    {
        public override void animalsound()
        {
            Console.WriteLine("Cat says: Maw Maw");
        }
    }
}
